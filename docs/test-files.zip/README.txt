Pediatric Visit Dashboard - test files
======================================

Every file is synthetic. Drop any of them onto the upload panel (or use Browse Files)
to see the state it is designed to trigger. Outcomes below were measured by running
the app's own parser over each file.

01-demo-visits.csv
    The built-in demo. 84 rows: 78 accepted, 9 adjusted, 6 skipped. Shows the
    data-quality panel with every warning category at least once.

02-clean-visits.csv
    12 rows, all accepted, no warnings. The quiet "all rows ready" state.

03-mixed-quality-rows.csv
    18 rows: 9 accepted, 7 adjusted, 9 skipped, plus a header written as
    "Visit_ID". Six invalid dates, so the warning list shows the five-example cap.

04-missing-column.csv
    Rejected. The provider_id column is absent; the message names it and lists the
    six columns that were found.

05-empty.csv
    Rejected. Zero bytes.

06-header-only.csv
    Rejected. A header row with no visit rows.

07-us-date-format.csv
    Loads, but every row is skipped because the dates are written month/day/year.
    Shows the "0 of 3 rows could be used" state with the expected format named.

08-ragged-rows.csv
    4 rows, 1 accepted, 3 skipped as ragged: an unquoted comma in a location, an
    extra trailing cell, and a missing cell. Shows the column-count safeguard.

09-weather-states.csv
    7 rows, all accepted. Select each location in the filter to see a different
    weather state: Bethesda, MD loads live weather; "Zzqxvqx, MD" has no map match;
    Hoboken, NJ has a 1935 visit, before the archive begins; Forest Hills, NY has a
    2030 visit, in the future; the blank location becomes Unknown and is never sent;
    "Zurich, CH" has no recognized U.S. state and is kept local.

10-header-case-and-extra-column.csv
    2 rows accepted. Headers in a different case and an extra "notes" column are
    accepted with an informational note; "fever" and "Fever" are grouped as one reason.
